def saludar (nombre):
    print("Hola", nombre + ", Bienvenido! ")

usuario = input("ingrese su nombre: ")
saludar(usuario)