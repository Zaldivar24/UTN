def operaciones(num1,num2):
    print("suma:", num1 + num2)
    print("resta:", num1 - num2)
    print("multiplicación:", num1 * num2)

a = float(input("Ingrese el primer numero: "))
b = float(input("Ingrese el segundo numero: "))

operaciones (a, b)

